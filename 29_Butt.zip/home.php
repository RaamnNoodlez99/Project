<?php

    session_start();

    if(!isset($_SESSION['userEmail'])){
        header("location: index.php");
    }

    include_once 'config.php';
    $email = '';
    $userID = '';
    if(isset($_SESSION['userEmail'])){
        $email = $_SESSION['userEmail'];
    }
    //GET USER ID//
    $sql = "SELECT * FROM users WHERE email = ?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: index.php?login=quick&error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($resultData)){
        $userID = $row['user_id'];
    }else{
        // header("location: home.php?error=nosession");
        exit();
    }
    mysqli_stmt_close($stmt);
    //end sql//



    $error_error = '';

    $userId = '';

    if(isset($_GET['error'])){
        if($_GET['error'] == 'none'){
            if(isset($_GET['add'])){
                if($_GET['add'] == 'true'){
                    


                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Ashir Butt, u20422475">
    <title>Exhibo | Home</title>
    <link rel="icon" type="image/x-icon" href="images/logo.svg">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/style.css">

    <script src="https://kit.fontawesome.com/c25dad79f1.js" crossorigin="anonymous"></script>
</head>
<body class="">
    <div class="container-fluid">
        <div class="header">
            <div class="nav">
                <div class="logo-banner">
                    <img class="logo-img" src="images/logo.svg" alt="website logo">
                    <h1>exhibo</h1>
                </div>
                <div class="page-links">
                    <a href='logout.php'>Logout</a>
                </div>
            </div>
        </div>


        <div class="background-images">

            <div class="gradient-home"></div>
            <div class="row">
                <div class="column">
                  <img src="images/background/img1.jpeg" alt="background-img">
                  <img src="images/background/img2.jpg" alt="background-img">
                  <img src="images/background/img4.jpg" alt="background-img">
                  <img src="images/background/img32.jpg" alt="background-img">
                  <img src="images/background/img36.jpg" alt="background-img">
                </div>
                <div class="column">
                    <img src="images/background/img5.jpg" alt="background-img">
                    <img src="images/background/img19.jpg" alt="background-img">
                    <img src="images/background/img33.jpg" alt="background-img">
                    <img src="images/background/img30.jpg" alt="background-img">
                    <img src="images/background/img37.jpg" alt="background-img">
                </div>
                <div class="column">
                    <img src="images/background/img10.jpg" alt="background-img">
                    <img src="images/background/img7.jpg" alt="background-img">
                    <img src="images/background/img9.jpg" alt="background-img">
                    <img src="images/background/img34.jpg" alt="background-img">
                    <img src="images/background/img39.jpg" alt="background-img">
                </div>
                <div class="column">
                  <img src="images/background/img11.jpg" alt="background-img">
                  <img src="images/background/img12.jpg" alt="background-img">
                  <img src="images/background/img13.jpg" alt="background-img">
                  <img src="images/background/img35.jpg" alt="background-img">
                  <img src="images/background/img38.jpg" alt="background-img">
                </div>
                <div class="column">
                  <img src="images/background/img15.jpg" alt="background-img">
                  <img src="images/background/img31.jpg" alt="background-img">
                  <img src="images/background/img29.jpg" alt="background-img">
                  <img src="images/background/img8.jpg" alt="background-img">
                  <img src="images/background/img14.jpg" alt="background-img">
                </div>
                <div class="column">
                  <img src="images/background/img23.jpg" alt="background-img">
                  <img src="images/background/img24.jpg" alt="background-img">
                  <img src="images/background/img25.jpg" alt="background-img">
                  <img src="images/background/img27.jpg" alt="background-img">
                  <img src="images/background/img21.jpg" alt="background-img">
                </div>
              </div>
        </div>
    </div>

    <div id="add-event-button" class="add-event-button">
    <i class="fa-solid fa-plus"></i>
    </div>

    <div id="eventForm" class="add-event-form">
            <div class="add-cover">
            <h1>Add an artwork</h1>

            <form action="addEvent.php" method="POST" enctype="multipart/form-data">
                <fieldset>
                    <div class="row">
                        <div class="col-12">
                            <label for="name">Artwork Name<sup>*</sup></label>
                            <input type="text" id="name" class="form-control" name="name">
                            <span class="formspan" id="nameSpan"></span>
                        </div>
                        <div class="col-12">
                            <label for="description">Artwork Description<sup>*</sup></label><br/>
                            <textarea class="form-control" name="description" id="description"></textarea>
                            <span class="formspan" id="descriptionSpan"></span>
                        </div>
                        <div class="col-12">
                            <label for="date">Creation Date<sup>*</sup></label><br/>
                            <input type="date" id="date" class="form-control" name="date">
                            <span class="formspan" id="dateSpan"></span>
                        </div>
                        <div class="col-12">
                            <label for="location">Creation Location<sup>*</sup></label>
                            <input type="text" id="location" class="form-control" name="location">
                            <span class="formspan" id="locationSpan"></span>
                        </div>
                        <div class="col-12">
                            <label for="hashtags">Hashtags<sup>*</sup></label>
                            <input type="text" id="hashtags" class="form-control" name="hashtags">
                            <span class="formspan" id="hashtagSpan"></span>
                        </div>
                        <label name="image" id="picLabel" for="picToUpload">Upload Artwork</label>
                        <input type='file' class='form-control' name='picToUpload' id='picToUpload' />
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <button name="addSubmit" type="submit" id="addSubmit" class="btn">Add Artwork</button>
                            <span class="formspan" id="errorSpan"><?php echo $error_error?></span>
                        </div>
                    </div>
                </fieldset>
            </form>

            </div>
        </div>

        <div class="all-events">

            <?php
                $query = "SELECT * FROM events WHERE `user_id` = $userID";
                $response = $conn->query($query);

                $eventsArray = array();
				$countEvents = 0;

                if($response->num_rows > 0){
					while($row = $response->fetch_assoc()){
						$eventsArray[$countEvents++] = $row; 
					}
				}

                if(!empty($eventsArray)){
                    foreach($eventsArray as $row){

						$tempEventID = $row['event_id'];
                        $imgName = $row['image'];
                        $hashtags = $row['hashtags'];

                        $hashArr = explode(" ", $hashtags);

						echo '<div class="an-event">
                                <div class="img-side">
                                    <img src="images/events/' . $imgName . '" alt="event">
                                </div>
                                <div class="text-side">
                                    <h1 class="eName">' . $row['name'] . '</h1>
                                    <hr class="mar-bot">
                                    <p class="eDescription">' . $row['description'] . '</p>
                                    <p class="lighter eDate">Creation date: <span class="darker">' . $row['date'] . '</span></p>
                                    <p class="lighter eLocation">Location: <span class="darker">' . $row['location'] . '</span></p>
                                    <div class="eHashtags">';

                                    foreach($hashArr as $hash){
                                        echo '<div class="eHashtag">' . $hash . '</div>';
                                    }

                        echo        '</div>
                                </div>
                            </div>';
					}
                }
            ?>
            <!-- <div class="an-event">
                <div class="img-side">
                    <img src="images/events/one.jpeg" alt="eventOne">
                </div>
                <div class="text-side">
                    <h1 class="eName">Firefist Ace</h1>
                    <hr class="mar-bot">
                    <p class="eDescription">Portgas D. Ace, born as Gol D. Ace and nicknamed "Fire Fist" Ace, was the sworn older 
                        brother of Luffy and Sabo, and the biological son of the late Pirate King, Gol D. Roger, 
                        and Portgas D. Rouge. Ace was adopted by Monkey D. Garp, as had been requested by Roger 
                        before his execution. Ace was the 2nd division commander of the Whitebeard Pirates and 
                        one-time captain of the Spade Pirates.</p>
                    <p class="lighter eDate">Creation date: <span class="darker">16 January 2011</span></p>
                    <p class="lighter eLocation">Location: <span class="darker">Paducah, Texas(TX), USA</span></p>

                    <div class="eHashtags">
                        <div class="eHashtag">
                            One Piece
                        </div>
                        <div class="eHashtag">
                            Portgas D. Ace
                        </div>
                        <div class="eHashtag">
                            Luffy
                        </div>
                        <div class="eHashtag">
                            Shiken!
                        </div>
                    </div>
                </div>
            </div> -->

            <!-- <div class="an-event">
                <div class="img-side">
                    <img src="images/events/two.jpeg" alt="eventOne">
                </div>
                <div class="text-side">
                    <h1 class="eName">Firefist Ace</h1>
                    <hr class="mar-bot">
                    <p class="eDescription">Portgas D. Ace, born as Gol D. Ace and nicknamed "Fire Fist" Ace, was the sworn older 
                        brother of Luffy and Sabo, and the biological son of the late Pirate King, Gol D. Roger, 
                        and Portgas D. Rouge. Ace was adopted by Monkey D. Garp, as had been requested by Roger 
                        before his execution. Ace was the 2nd division commander of the Whitebeard Pirates and 
                        one-time captain of the Spade Pirates.</p>
                    <p class="lighter eDate">Creation date: <span class="darker">16 January 2011</span></p>
                    <p class="lighter eLocation">Location: <span class="darker">Paducah, Texas(TX), USA</span></p>

                    <div class="eHashtags">
                        <div class="eHashtag">
                            One Piece
                        </div>
                        <div class="eHashtag">
                            Portgas D. Ace
                        </div>
                        <div class="eHashtag">
                            Luffy
                        </div>
                        <div class="eHashtag">
                            Shiken!
                        </div>
                    </div>
                </div>
            </div> -->

        </div>

        <script src="js/home.js"></script>
</body>
</html>