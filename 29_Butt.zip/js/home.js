let addView = false;
let addButton = document.getElementById('add-event-button');
let addForm = document.getElementById('eventForm');

if(addView == false){
    addForm.classList.remove('show');
    addForm.classList.add('hide');
    addView = true;
}

function changeView(){
    if(addView == false){
        addForm.classList.remove('show');
        addForm.classList.add('hide');
        addView = true;
    }else{
        addForm.classList.remove('hide');
        addForm.classList.add('show');
        addView = false;
    }
}

addButton.onclick = function(){
    changeView();
}